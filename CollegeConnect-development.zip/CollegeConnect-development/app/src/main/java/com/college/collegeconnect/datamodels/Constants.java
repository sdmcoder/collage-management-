package com.college.collegeconnect.datamodels;

public class Constants {

    public static final String STORAGE_PATH_UPLOADS = "notes/";
    public static final String DATABASE_PATH_UPLOADS = "notes";
    public static final String EVENTS_PATH_UPLOAD = "Events";
    public static final String BVEST_EVENT_PATH="Bvest/events";
    public static final String BVEST_SOCIETY_PATH="Bvest/societies";
    public static final String BVEST_REGISTER_PATH="Bvest/registerations";
}
