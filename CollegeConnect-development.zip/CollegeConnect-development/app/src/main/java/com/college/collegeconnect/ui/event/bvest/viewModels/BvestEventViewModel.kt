package com.college.collegeconnect.ui.event.bvest.viewModels

import androidx.lifecycle.ViewModel

class BvestEventViewModel:ViewModel() {
    
}