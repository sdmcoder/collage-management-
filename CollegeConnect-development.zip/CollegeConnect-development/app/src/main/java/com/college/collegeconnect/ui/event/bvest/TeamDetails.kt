package com.college.collegeconnect.ui.event.bvest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.college.collegeconnect.R

class TeamDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team_details)
        if(intent!=null){
            //TODO("Create TeamDetails UI and set values")
            //TODO("Add a button")
            //TODO("OnClick take email and name from shared preferences")
            //TODO("Add teamMate and updateUI")
        }
    }
}