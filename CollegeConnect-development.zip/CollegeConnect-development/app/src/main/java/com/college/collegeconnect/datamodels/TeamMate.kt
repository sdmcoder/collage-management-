package com.college.collegeconnect.datamodels

import java.io.Serializable

data class TeamMate(
        val name: String? = null,
        val email: String? = null,
) : Serializable