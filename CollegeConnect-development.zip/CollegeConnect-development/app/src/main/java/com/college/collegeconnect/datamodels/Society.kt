package com.college.collegeconnect.datamodels

data class Society(val name:String?=null,val image:String?=null)